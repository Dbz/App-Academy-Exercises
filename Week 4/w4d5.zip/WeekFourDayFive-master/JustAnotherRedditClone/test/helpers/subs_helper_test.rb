require 'test_helper'

class SubsHelperTest < ActionView::TestCase
end
