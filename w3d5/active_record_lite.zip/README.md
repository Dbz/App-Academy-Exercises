# Active Record Lite!

Instructions for the project may be found [here][instructions].

[instructions]: https://github.com/appacademy/sql-curriculum/blob/master/projects/w3d5-build-your-own-ar.md
